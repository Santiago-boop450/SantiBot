> <b> Versión 2.1 </b>


<p align="center">
<a href="#"><img title="ansí-BOT" src="https://github.com/Eliasar54/ansi-BOT-MD/blob/main/media/20241107_180251.jpg"alt="ansí-BOT" style="width:100%; max-width:400px;"></a>
</p>
<p align="center">
<img src="http://readme-typing-svg.herokuapp.com?font=mono&size=14&duration=3000&color=0000FF&center=true&vCenter=true&lines=La+aventura+apenas+empieza." height="40px">
</p>

<p align="centro">
<a href="#"><img title="Supra-BOT" src="https://img.shields.io/badge/SI%20TE%20AGRADA%20EL%20REPOSITORIO%20APOYAME%20CON%20UNA%20%E2%AD%90%20%C2%A1GRACIAS!%20-red?colorA=%23ffff00&colorB=%23ffff00&style=for-the-badge"></a>
<a href="#"><img title="Eliasar" src="https://img.shields.io/badge/COMPATIBLE CON LA VERSIÓN MULTI DISPOSITIVOS DE WHATSAPP-red?colorA=%23ffff00&colorB=%23ffff00&style=for-the-badge">
<div align="centro">
<a href="https://tinyurl.com/27hyghwa/">
<img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" alt="Facebook">
</a>
<a href="https://www.youtube.com/@EliasarYT">
<img src="https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white" alt="YouTube">
</a>

[![Enlaces](https://img.shields.io/badge/Encontra_todos_los_enlaces_en_un_único_lugar-000000%7D?style=for-the-badge&logo=biolink&logoColor=white)](https://atom.bio/blogansi)
</div>
    
### `👑 DUDAS SOBRE EL BOT?, CONTACTAME 👑`
<p align="centro">
<a href="https://Eliasar54@github.com"><img src="http://readme-typing-svg.herokuapp.com?font=mono&size=14&duration=3000&color=ABF7BB¢er=verdadero&vCenter=verdadero&lines=Solo+escr%C3%ADba+si+tiene+dudas." height="40px"
</p>
    
<a href="https://wa.me/50582340051" target="blank"><img src="https://img.shields.io/badge/Creador-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" /></a>

### Quieres probar las funciones del bot, antes de instalar, prueba el bot aquí

[![Grupos](https://img.shields.io/badge/Grupos-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://chat.whatsapp.com/CPGKvG1sV3v4wOwF6c1UiD)

------------------


## 𝙰𝙲𝚃𝙸𝚅𝙰 𝙴𝙻 𝚃𝙴𝚁𝙼𝚄𝚇
👇 Pasos para instalar el bot via termux 👇

[![blog](https://img.shields.io/badge/Video-Tutorial-FF0000?style=for-the-badge&logo=youtube&logoColor=white)
](https://www.youtube.com/@EliasarYT)

[`💫 Instalar termux clic aqui`](https://www.mediafire.com/file/3hsvi3xkpq3a64o/termux_118.apk/file)

```bash
termux-setup-storage
```

```bash
apt update && apt upgrade && pkg update && pkg upgrade && pkg install bash && pkg install libwebp && pkg install git -y && pkg install nodejs -y && pkg install ffmpeg -y && pkg install wget && pkg install imagemagick -y && pkg install yarn
```
```bash
git clone https://github.com/Eliasar54/ansi-BOT-MD && cd ansi-BOT-MD && npm install
```
```bash
npm start
```

### `💥 𝙎𝙔 𝙔𝘼 𝘼𝙎 𝘿𝙀𝙎𝘾𝘼𝙍𝙂𝘼𝘿𝙊 𝙐𝙉 𝘽𝙊𝙏 𝙎𝙊𝙇𝙊 𝙐𝙎𝘼 𝙇𝙊𝙎 𝙎𝙄𝙂𝙐𝙄𝙀𝙉𝙏𝙀𝙎 𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎`

```bash
git clone https://github.com/Eliasar54/ansi-BOT-MD && cd ansi-BOT-MD && npm install
```
```bash
npm start
```

### `💥  𝙰𝙲𝚃𝙸𝚅𝙰𝚁 𝙴𝙽 𝙲𝙰𝚂𝙾 𝙳𝙴 𝙳𝙴𝚃𝙴𝙽𝙴𝚁𝚂𝙴 𝙴𝙽 𝚃𝙴𝚁𝙼𝚄𝚇`
Si despues que ya instalas tu bot y termux te salta en blanco, se fue tu internet o reiniciaste tu celular, solo realizas estos pasos
```bash
> cd ansi-BOT-MD
> npm start
```
### `,💥  𝙾𝙱𝚃𝙴𝙽𝙴𝚁 𝙾𝚃𝚁𝙾 𝙲𝙾𝙳𝙸𝙶𝙾 𝚀𝚁 𝙴𝙽 𝚃𝙴𝚁𝙼𝚄𝚇`
Detener el bot apretado CTRL y aplastas Z en tu teclado, darle enter y escribe:

```bash
> cd 
> cd ansi-BOT-MD
> rm -rf sessions
> npm start
```

------------------

### 👾 AZURA ULTRA
<a href="https://store.azuraultra-host.pro/login"><img src="https://qu.ax/ewVT.jpg" height="125px"></a>
### Información del Host

- **Dashboard:** [`Aquí`](https://control.azuraultra-host.pro/)
- **Panel:** [`Aquí`](https://control.azuraultra-host.pro/)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029VaWABAMG8l5K8K9PAB3v)

### 🚀 CORINPLUS-HOST 🚀
<a href="https://dash.corinplus.com"><img src="https://qu.ax/ZycD.png" height="125px"></a>
### Información del Host

- **Dashboard:** [`Aquí`](https://dash.corinplus.com)
- **Panel:** [`Aquí`](https://panel.corinplus.com)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029VakUvreFHWpyWUr4Jr0g)
- **Soporte:** [`Aquí`](https://chat.whatsapp.com/K235lkvaGvlGRQKYm26xZP)






------------------
### ACTIVAR EN CODIGOS ESPACIOS

[`CREAR SERVIDOR`](https://github.com/codespaces/new?skip_quickstart=true&machine=standardLinux32gb&repo=836499897&ref=main&geo=UsEast)

------------------

<a href="https://github.com/Eliasar54/ansi-BOT-MD" target="_blank"> 
    <img src="https://telegra.ph/file/bd13a944d2b0632cb8707.jpg" alt="Ansi" width="150"/> 
</a> 


***

## `𝗘𝗗𝗜𝗧𝗢𝗥 𝗜 𝗣𝗥𝗢𝗣𝗜𝗘𝗧𝗔𝗥𝗜𝗢`

<a href="https://Eliasar54@github.com"><img src="https://github.com/Eliasar54.png" width="250" height="250" alt="Eliasar54"/></a>


> ### 📜 Créditos
> <a href="https://github.com/elrebelde21"><img src="https://github.com/elrebelde21.png" width="250" height="250" alt="elrebelde21"/></a>
> 
> [`elrebelde21`](https://github.com/elrebelde21)
> 


> ### 🤝 Contribuidores del Código Original
> 
> **[OfcDiego](https://github.com/OfcDiego)**
> <a href="https://github.com/OfcDiego"><img src="https://github.com/OfcDiego.png" width="50" height="50" style="border-radius:50%;" alt="OfcDiego"/></a>
> 
> **[AzamiJs](https://github.com/AzamiJs)**
> <a href="https://github.com/AzamiJs"><img src="https://github.com/AzamiJs.png" width="50" height="50" style="border-radius:50%;" alt="AzamiJs"/></a>
> 
> **[sensei-ofc](https://github.com/sensei-ofc)**
> <a href="https://github.com/sensei-ofc"><img src="https://github.com/sensei-ofc.png" width="50" height="50" style="border-radius:50%;" alt="sensei-ofc"/></a>
> 
> **[Skidy89](https://github.com/Skidy89)**
> <a href="https://github.com/Skidy89"><img src="https://github.com/Skidy89.png" width="50" height="50" style="border-radius:50%;" alt="Skidy89"/></a>
> 
> **[KatashiFukushima](https://github.com/KatashiFukushima)**
> <a href="https://github.com/KatashiFukushima"><img src="https://github.com/KatashiFukushima.png" width="50" height="50" style="border-radius:50%;" alt="KatashiFukushima"/></a>
> 
> **[HACHEJOTA](https://github.com/HACHEJOTA)**
> <a href="https://github.com/HACHEJOTA"><img src="https://github.com/HACHEJOTA.png" width="50" height="50" style="border-radius:50%;" alt="HACHEJOTA"/></a>
> 
> **[Alba070503](https://github.com/Alba070503)**
> <a href="https://github.com/Alba070503"><img src="https://github.com/Alba070503.png" width="50" height="50" style="border-radius:50%;" alt="Alba070503"/></a>
> 
> **[DIEGO-OFC](https://github.com/DIEGO-OFC)**
> <a href="https://github.com/DIEGO-OFC"><img src="https://github.com/DIEGO-OFC.png" width="50" height="50" style="border-radius:50%;" alt="DIEGO-OFC"/></a>
> 
> **[glytglobal](https://github.com/glytglobal)**
> <a href="https://github.com/glytglobal"><img src="https://github.com/glytglobal.png" width="50" height="50" style="border-radius:50%;" alt="glytglobal"/></a>
